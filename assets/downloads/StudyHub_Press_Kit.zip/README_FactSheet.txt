STUDYHUB - PRESS & CREATOR FACT SHEET
=====================================

Title: StudyHub
Developer & Publisher: Solid Illusion (solo developer: Regina)
Website: https://solidillusion.com
Steam Store Page: https://store.steampowered.com/app/3985980/StudyHub/
Latest Update (v0.3.0.7): https://store.steampowered.com/news/app/3985980/view/710041502255940175
Discord Community: https://discord.gg/M4FGr8gNNs
YouTube: https://www.youtube.com/@solid.illusion
Press & Creator Contact: contact@solidillusion.com

Platform: Windows PC (Steam)
Price: Free-to-Play (optional cosmetic items & Library Cards)
Download Size: ~760 MB (built to run smoothly on student laptops)
Languages: 18 languages supported

ELEVATOR PITCH
--------------
StudyHub is a quiet, multiplayer 3D study library on Steam. There is no microphone, no camera, and no pressure to chat. Students, remote workers, and co-working streamers can drop into shared sunlit rooms, sit at desks beside people studying worldwide, and stay focused with built-in productivity tools.

KEY FEATURES
------------
- Multiplayer Focus, Zero Awkwardness: Share a calm 3D library with real people across the world, with no mic or webcam required.
- Built-In Study Toolkit: Pomodoro timer, to-do list, sticky notes, study journal, and curated lo-fi radio right at your desk.
- Dynamic Atmosphere & 3 Library Floors: Switch between bright morning, golden sunset, and starry late-night lighting across three distinct library floors and an outdoor campus courtyard.
- Expressive Avatars: Customize hairstyles, outfits, and colors, and earn HubCoins as you study.
- Lightweight by Design: ~760 MB download with low VRAM usage so it runs comfortably alongside browser tabs, PDFs, and lectures.

FOR CO-WORKING & STUDY WITH ME CREATORS
---------------------------------------
Hosting a co-working stream on Twitch or YouTube? Invite your viewers into the same 3D library room for free so they can sit at desks around you during Pomodoro blocks.
Email contact@solidillusion.com to request complimentary Supporter Library Card codes for your channel and Member Card giveaway codes for your community.

INCLUDED IN THIS PRESS KIT
--------------------------
- Logos/StudyHub_Logo_V20.png (high-res transparent wordmark)
- Logos/StudyHub_Icon_512x512.png (transparent app icon)
- Logos/Solid_Illusion_Logo_White.png (transparent white studio mark for dark backgrounds)
- Screenshots/ (5 clean 1920x1080 in-game screenshots)
